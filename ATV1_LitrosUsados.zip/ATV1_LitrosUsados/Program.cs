﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATV1_LitrosUsados
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Receber informações 
            Console.WriteLine("Digite o tempo percorrido");
            float tempo = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite a velocidade média percorrida");
            float VM = float.Parse(Console.ReadLine());

            // Saber a distância
            var distancia = tempo * VM;

            // Saber litros usados
            float L_Usados = distancia / 12;
            Console.WriteLine("Litros usados: " + L_Usados);
            Console.ReadLine();
        }
    }
}
